package ch.bbbaden.lohnabrechner.login;

import ch.bbbaden.lohnabrechner.database.DbAccess;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * von der SecureApp inspiriert im Modul 183
 * @author Metehan
 */
public class LoginDAO {

    public LoginDAO() {
        if (!DbAccess.tableExists("login")) {
            createInitialLogin();
        }
    }
    
    private void createInitialLogin(){
        final String sql = "CREATE TABLE IF NOT EXISTS login ("
                + " id INTEGER PRIMARAY KEY,"
                + " name TEXT NOT NULL,"
                + " password TEXT NOT NULL,"
                + " is_admin_login INTEGER DEFAULT 0 NOT NULL"
                + ");";
        try (Statement statement = DbAccess.getConnection().createStatement()){
            statement.execute(sql);
        }catch (SQLException e) {
            Logger.getLogger(DbAccess.class.getName()).log(Level.SEVERE, null, e);
        }
        
        insert(new User(0, "arbeitnehmer", "arbeitnehmer123", false));
        insert(new User(0, "arbeitgeber", "arbeitgeber123", false));
        insert(new User(0, "admin", "admin123", true));
    }
    
    public List<User> getAll(){
        final String sql = "SELECT id, name, password, is_admin_login FROM login ORDER BY id ASC";
        ArrayList<User> allUser = new ArrayList<>();
        
        try (Statement stmt = DbAccess.getConnection().createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            // loop through the result set
            while (rs.next()) {
                allUser.add(new User(rs.getInt("id"), rs.getString("name"), rs.getString("password"), rs.getBoolean("is_admin_login")));
            }
        } catch (SQLException e) {
            Logger.getLogger(LoginDAO.class.getName()).log(Level.SEVERE, null, e);
        }
        return allUser;
    }
    
    public int insert(User user) {
        final String sql = "INSERT INTO login (name, password, is_admin_login) VALUES ('" + user.getName() + "','" + user.getPassword() + "','" + (user.getIsAdminLogin() ? "1" : "0") + ")";
        int id = 0;

        try (Statement stmt = DbAccess.getConnection().createStatement()) {
            stmt.execute(sql);
            id = stmt.getGeneratedKeys().getInt(1);
        } catch (SQLException e) {
            Logger.getLogger(LoginDAO.class.getName()).log(Level.SEVERE, null, e);
        }
        return id;
    }
    
    public void edit(User user) {
        final String sql = "UPDATE login SET "
                + "name='"+user.getName()+"',"
                + "password='"+user.getPassword()+"',"
                + "is_admin_login="+(user.getIsAdminLogin() ? "1" : "0")
                + " WHERE id = "+user.getId();

        try (Statement stmt = DbAccess.getConnection().createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            Logger.getLogger(LoginDAO.class.getName()).log(Level.SEVERE, null, e);
        }
    }
    
    public void delete(User user) {
        final String sql = "DELETE FROM news WHERE id = "+user.getId();

        try (Statement stmt = DbAccess.getConnection().createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            Logger.getLogger(LoginDAO.class.getName()).log(Level.SEVERE, null, e);
        }
    }
    
    public User getById(long id) {
        final String sql = "SELECT id, name, password, is_admin_login FROM user WHERE id = "+id;

        User user = null;
        
        try (Statement stmt = DbAccess.getConnection().createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
            if(rs.next()) {
                user = new User(rs.getInt("id"), rs.getString("name"), rs.getString("password"), rs.getBoolean("is_admin_login"));
            }            
        } catch (SQLException e) {
            Logger.getLogger(LoginDAO.class.getName()).log(Level.SEVERE, null, e);
        }
        return user;
    }
}
